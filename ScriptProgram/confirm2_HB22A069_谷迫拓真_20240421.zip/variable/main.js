"use strict";

window.onload = function () {
    let hoge;
    let piyo = 123.456;
    let fuga = "文字列";
    hoge = 10;
    piyo = hoge;
    document.write("hoge:" + hoge + "<br/>");
    document.write("piyo:" + piyo + "<br/>");
    document.write("fuga:" + fuga + "<br/>");
}
