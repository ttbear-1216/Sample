"use strict";

window.onload = function () {
    const ZEIRITSU = 0.08;
    document.write("税率:" + ZEIRITSU + "<br/>");
    ZEIRITSU = 0.10;
    document.write("税率:" + ZEIRITSU + "<br/>");
}
