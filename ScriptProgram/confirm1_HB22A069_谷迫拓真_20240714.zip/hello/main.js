"use strict";

window.onload = function () {
    document.write("Hello,world!");
    alert("Hello,alert!");
    console.log("Hello,consoleLog!");
}
